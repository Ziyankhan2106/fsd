import numpy as np

np.random.seed(1)

X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
y = np.array([[0], [1], [1], [0]])

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def bce_loss(y, a2):
    eps = 1e-9
    return -np.mean(y * np.log(a2 + eps) + (1 - y) * np.log(1 - a2 + eps))

W1 = np.random.randn(2, 4)
b1 = np.zeros((1, 4))
W2 = np.random.randn(4, 1)
b2 = np.zeros((1, 1))

lr = 0.5
n = len(X)
eps = 1e-9

for epoch in range(10000):

    # ---------- Forward pass ----------
    z1 = X @ W1 + b1
    a1 = sigmoid(z1)
    z2 = a1 @ W2 + b2
    a2 = sigmoid(z2)

    loss = bce_loss(y, a2)


    # 1) dLoss/da2 : how loss changes with the network output
    #    Loss = -mean[ y ln(a2) + (1-y) ln(1-a2) ]
    dLoss_da2 = (a2 - y) / (a2 * (1 - a2) + eps) / n      # /n from the mean

    # 2) da2/dz2 : sigmoid derivative at the output
    da2_dz2 = a2 * (1 - a2)

    # 3) dLoss/dz2 = dLoss/da2 * da2/dz2   (a2(1-a2) cancels -> (a2 - y)/n)
    dLoss_dz2 = dLoss_da2 * da2_dz2

    # 4) dz2/dW2 = a1,  dz2/db2 = 1
    dz2_dW2 = a1
    dLoss_dW2 = dz2_dW2.T @ dLoss_dz2                      # (4,4)@(4,1) = (4,1)
    dLoss_db2 = np.sum(dLoss_dz2, axis=0, keepdims=True)   # (1,1)

    # 5) dz2/da1 = W2 : push the error back to the hidden activations
    dz2_da1 = W2
    dLoss_da1 = dLoss_dz2 @ dz2_da1.T                      # (4,1)@(1,4) = (4,4)

    # 6) da1/dz1 : sigmoid derivative at the hidden layer
    da1_dz1 = a1 * (1 - a1)

    # 7) dLoss/dz1 = dLoss/da1 * da1/dz1
    dLoss_dz1 = dLoss_da1 * da1_dz1

    # 8) dz1/dW1 = X,  dz1/db1 = 1
    dz1_dW1 = X
    dLoss_dW1 = dz1_dW1.T @ dLoss_dz1                      # (2,4)@(4,4) = (2,4)
    dLoss_db1 = np.sum(dLoss_dz1, axis=0, keepdims=True)   # (1,4)
    
    W2 -= lr * dLoss_dW2
    b2 -= lr * dLoss_db2
    W1 -= lr * dLoss_dW1
    b1 -= lr * dLoss_db1

    if epoch % 2000 == 0:
        print(f"Epoch {epoch}, Loss: {loss:.5f}")

# Final predictions
a1 = sigmoid(X @ W1 + b1)
a2 = sigmoid(a1 @ W2 + b2)

print("\nXOR Gate Output")
for xi, out in zip(X, a2):
    print(xi, "->", round(out[0], 3), "=>", int(out[0] > 0.5))
    
    
    
# dLoss/dW2 = dLoss/da2 · da2/dz2 · dz2/dW2
# dLoss/db2 = dLoss/da2 · da2/dz2 · dz2/db2

# dLoss/dW1 = dLoss/da2 · da2/dz2 · dz2/da1 · da1/dz1 · dz1/dW1
# dLoss/db1 = dLoss/da2 · da2/dz2 · dz2/da1 · da1/dz1 · dz1/db1