import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris, fetch_openml
from sklearn.model_selection import train_test_split, ParameterGrid, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC, SVR

# helper: try every combination in the grid, keep the one with best CV score
def tune(Model, grid, X, y):
    best_score, best_params = -np.inf, None
    for params in ParameterGrid(grid):
        score = cross_val_score(Model(**params), X, y, cv=5).mean()
        if score > best_score:
            best_score, best_params = score, params
    return best_params, best_score

# ================= 1. CLASSIFICATION (Iris) =================
X, y = load_iris(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
scaler = StandardScaler().fit(X_train)
X_train, X_test = scaler.transform(X_train), scaler.transform(X_test)

grid = {"C": [0.1, 1, 10, 100], "kernel": ["linear", "rbf"], "gamma": ["scale", 0.1, 1]}
params, score = tune(SVC, grid, X_train, y_train)
model = SVC(**params).fit(X_train, y_train)
print("SVC best params :", params)
print("SVC CV accuracy : %.3f" % score)
print("SVC test accuracy: %.3f" % model.score(X_test, y_test))

# --- hyperplane plot: 2 classes + 3 features + linear kernel ---
X, y = load_iris(return_X_y=True)
keep = y != 0                           # Versicolor vs Virginica
X3 = StandardScaler().fit_transform(X[keep][:, [0, 2, 3]])
y2 = y[keep]

params, _ = tune(SVC, {"C": [0.1, 1, 10, 100], "kernel": ["linear"]}, X3, y2)
clf = SVC(**params).fit(X3, y2)
w, b = clf.coef_[0], clf.intercept_[0]

# plane:  w0*x + w1*y + w2*z + b = 0   ->   z = -(w0*x + w1*y + b) / w2
xx, yy = np.meshgrid(np.linspace(-2.5, 2.5, 10), np.linspace(-2.5, 2.5, 10))
zz = -(w[0] * xx + w[1] * yy + b) / w[2]

ax = plt.figure(figsize=(7, 6)).add_subplot(projection="3d")
ax.scatter(*X3[y2 == 1].T, c="blue", label="Versicolor")
ax.scatter(*X3[y2 == 2].T, c="red", label="Virginica")
ax.plot_surface(xx, yy, zz, alpha=0.3, color="green")
ax.set_zlim(X3[:, 2].min(), X3[:, 2].max())
ax.set(xlabel="Sepal length", ylabel="Petal length", zlabel="Petal width",
       title="SVC hyperplane")
ax.legend()
plt.savefig("svc_plane.png", dpi=150)

# ================= 2. REGRESSION (Boston housing) =================
try:
    boston = fetch_openml(name="boston", version=1, as_frame=True)
    X = boston.data[["RM", "LSTAT"]].astype(float).values
    y = boston.target.astype(float).values
except Exception:
    print("(offline: using fake data just to demo the code)")
    rng = np.random.RandomState(0)
    X = np.c_[rng.uniform(4, 9, 400), rng.uniform(2, 35, 400)]
    y = 5 * X[:, 0] - 0.6 * X[:, 1] + rng.normal(0, 2, 400)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
scaler = StandardScaler().fit(X_train)
X_train, X_test = scaler.transform(X_train), scaler.transform(X_test)

grid = {"kernel": ["linear"], "C": [1, 10, 100], "epsilon": [0.1, 0.5, 1.0]}
params, score = tune(SVR, grid, X_train, y_train)
reg = SVR(**params).fit(X_train, y_train)
print("\nSVR best params :", params)
print("SVR CV R2       : %.3f" % score)
print("SVR test R2     : %.3f" % reg.score(X_test, y_test))

# linear SVR  ->  price = w0*RM + w1*LSTAT + b   (a plane)
w, b = reg.coef_[0], reg.intercept_[0]
xx, yy = np.meshgrid(np.linspace(-2.5, 2.5, 10), np.linspace(-2.5, 2.5, 10))
zz = w[0] * xx + w[1] * yy + b

ax = plt.figure(figsize=(7, 6)).add_subplot(projection="3d")
ax.scatter(X_train[:, 0], X_train[:, 1], y_train, c="blue", s=10, label="Data")
ax.plot_surface(xx, yy, zz, alpha=0.4, color="orange")
ax.set(xlabel="RM (scaled)", ylabel="LSTAT (scaled)", zlabel="Price",
       title="SVR hyperplane")
ax.legend()
plt.savefig("svr_plane.png", dpi=150)
plt.show()