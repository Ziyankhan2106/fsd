"""
Practical 7: SVM Classification & Regression with Grid Search
==============================================================
1. SVC on Iris dataset      - Grid Search for C, kernel, gamma
                             - 3D hyperplane plot
2. SVR on Boston Housing    - Grid Search for C, kernel, epsilon
                             - Actual vs Predicted plot
"""

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")  # non-interactive backend for saving plots
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

from sklearn.svm import SVC, SVR
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import (
    accuracy_score, classification_report, confusion_matrix,
    mean_squared_error, r2_score,
)

DATASET_DIR = os.path.join(os.path.dirname(__file__), "..", "datasets")
OUTPUT_DIR = os.path.dirname(__file__)

# ================================================================
#  PART 1: SVM Classification (SVC) on Iris Dataset
# ================================================================
print("=" * 65)
print("PART 1: SVM CLASSIFICATION (SVC) - Iris Dataset")
print("=" * 65)

# --- Load ---
iris = pd.read_csv(os.path.join(DATASET_DIR, "Iris.csv"))
feature_names = ["SepalLengthCm", "SepalWidthCm", "PetalLengthCm", "PetalWidthCm"]
X_cls = iris[feature_names].values
y_cls = LabelEncoder().fit_transform(iris["Species"])
class_names = ["setosa", "versicolor", "virginica"]

X_train, X_test, y_train, y_test = train_test_split(
    X_cls, y_cls, test_size=0.3, random_state=42
)

# --- Scale ---
scaler_cls = StandardScaler()
X_train_sc = scaler_cls.fit_transform(X_train)
X_test_sc = scaler_cls.transform(X_test)

# --- Grid Search ---
param_grid_svc = {
    "C": [0.1, 1, 10, 100],
    "kernel": ["linear", "rbf", "poly"],
    "gamma": ["scale", "auto"],
}

print("\nRunning Grid Search for SVC ...")
grid_svc = GridSearchCV(
    SVC(random_state=42),
    param_grid_svc,
    cv=5,
    scoring="accuracy",
    verbose=0,
    n_jobs=-1,
)
grid_svc.fit(X_train_sc, y_train)

print(f"Best Parameters : {grid_svc.best_params_}")
print(f"Best CV Accuracy: {grid_svc.best_score_:.4f}")

best_svc = grid_svc.best_estimator_
y_pred_cls = best_svc.predict(X_test_sc)

print(f"\nTest Accuracy   : {accuracy_score(y_test, y_pred_cls):.4f}")
print("\nConfusion Matrix:")
print(confusion_matrix(y_test, y_pred_cls))
print("\nClassification Report:")
print(classification_report(y_test, y_pred_cls, target_names=class_names))

# --- Grid Search Results Table ---
print("Grid Search Results (top 10):")
results_df = pd.DataFrame(grid_svc.cv_results_)
results_df = results_df.sort_values("rank_test_score")
print(results_df[["params", "mean_test_score", "rank_test_score"]].head(10).to_string(index=False))

# ── 3D Hyperplane Plot (using 3 best features) ──
# Use PetalLengthCm, PetalWidthCm, SepalLengthCm for 3D visualisation
# We pick two classes (setosa vs non-setosa) for a clear hyperplane
feat_idx = [0, 2, 3]  # SepalLength, PetalLength, PetalWidth
feat_labels = [feature_names[i] for i in feat_idx]

# Binary target: setosa (0) vs non-setosa (1)
y_binary = (y_cls != 0).astype(int)

X_3d = X_cls[:, feat_idx]
scaler_3d = StandardScaler()
X_3d_sc = scaler_3d.fit_transform(X_3d)

svc_3d = SVC(kernel="linear", C=1, random_state=42)
svc_3d.fit(X_3d_sc, y_binary)

fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111, projection="3d")

# Scatter points
colors = ["royalblue", "tomato"]
labels_bin = ["Setosa", "Non-Setosa"]
for cls_val in [0, 1]:
    mask = y_binary == cls_val
    ax.scatter(
        X_3d_sc[mask, 0], X_3d_sc[mask, 1], X_3d_sc[mask, 2],
        c=colors[cls_val], label=labels_bin[cls_val],
        edgecolors="k", s=50, alpha=0.8,
    )

# Draw hyperplane: w0*x0 + w1*x1 + w2*x2 + b = 0  =>  x2 = -(w0*x0 + w1*x1 + b) / w2
w = svc_3d.coef_[0]
b = svc_3d.intercept_[0]

xlim = ax.get_xlim()
ylim = ax.get_ylim()

xx, yy = np.meshgrid(
    np.linspace(xlim[0], xlim[1], 30),
    np.linspace(ylim[0], ylim[1], 30),
)
zz = -(w[0] * xx + w[1] * yy + b) / w[2]

ax.plot_surface(xx, yy, zz, alpha=0.3, color="gold", edgecolor="none")

ax.set_xlabel(feat_labels[0])
ax.set_ylabel(feat_labels[1])
ax.set_zlabel(feat_labels[2])
ax.set_title("SVM 3D Hyperplane (Setosa vs Non-Setosa)")
ax.legend(loc="upper left")

plot_path_cls = os.path.join(OUTPUT_DIR, "svc_3d_hyperplane.png")
plt.tight_layout()
plt.savefig(plot_path_cls, dpi=150)
plt.close()
print(f"\n3D Hyperplane plot saved to: {plot_path_cls}")


# ================================================================
#  PART 2: SVM Regression (SVR) on Boston Housing Dataset
# ================================================================
print("\n" + "=" * 65)
print("PART 2: SVM REGRESSION (SVR) - Boston Housing Dataset")
print("=" * 65)

# --- Load ---
boston = pd.read_csv(os.path.join(DATASET_DIR, "BostonHousing.csv"))
X_reg = boston.drop(columns=["medv"]).values
y_reg = boston["medv"].values

print(f"\nDataset shape: {boston.shape}")
print(f"Target (medv) : min={y_reg.min():.1f}, max={y_reg.max():.1f}, mean={y_reg.mean():.1f}")

X_train_r, X_test_r, y_train_r, y_test_r = train_test_split(
    X_reg, y_reg, test_size=0.3, random_state=42
)

# --- Scale ---
scaler_reg = StandardScaler()
X_train_r_sc = scaler_reg.fit_transform(X_train_r)
X_test_r_sc = scaler_reg.transform(X_test_r)

# --- Grid Search ---
param_grid_svr = {
    "C": [0.1, 1, 10, 100],
    "kernel": ["linear", "rbf"],
    "epsilon": [0.01, 0.1, 0.5],
    "gamma": ["scale", "auto"],
}

print("\nRunning Grid Search for SVR ...")
grid_svr = GridSearchCV(
    SVR(),
    param_grid_svr,
    cv=5,
    scoring="r2",
    verbose=0,
    n_jobs=-1,
)
grid_svr.fit(X_train_r_sc, y_train_r)

print(f"Best Parameters: {grid_svr.best_params_}")
print(f"Best CV R2     : {grid_svr.best_score_:.4f}")

best_svr = grid_svr.best_estimator_
y_pred_reg = best_svr.predict(X_test_r_sc)

mse = mean_squared_error(y_test_r, y_pred_reg)
rmse = np.sqrt(mse)
r2 = r2_score(y_test_r, y_pred_reg)

print(f"\nTest MSE  : {mse:.4f}")
print(f"Test RMSE : {rmse:.4f}")
print(f"Test R2   : {r2:.4f}")

# --- Grid Search Results Table ---
print("\nGrid Search Results (top 10):")
results_svr = pd.DataFrame(grid_svr.cv_results_)
results_svr = results_svr.sort_values("rank_test_score")
print(results_svr[["params", "mean_test_score", "rank_test_score"]].head(10).to_string(index=False))

# --- Actual vs Predicted Plot ---
fig, ax = plt.subplots(figsize=(8, 6))
ax.scatter(y_test_r, y_pred_reg, c="steelblue", edgecolors="k", alpha=0.7, s=40)
lims = [min(y_test_r.min(), y_pred_reg.min()) - 2,
        max(y_test_r.max(), y_pred_reg.max()) + 2]
ax.plot(lims, lims, "r--", linewidth=1.5, label="Ideal (y=x)")
ax.set_xlabel("Actual medv")
ax.set_ylabel("Predicted medv")
ax.set_title(f"SVR: Actual vs Predicted (R2={r2:.3f}, RMSE={rmse:.2f})")
ax.legend()
ax.grid(True, alpha=0.3)

plot_path_reg = os.path.join(OUTPUT_DIR, "svr_actual_vs_predicted.png")
plt.tight_layout()
plt.savefig(plot_path_reg, dpi=150)
plt.close()
print(f"\nActual vs Predicted plot saved to: {plot_path_reg}")


# ================================================================
#  Summary
# ================================================================
print("\n" + "=" * 65)
print("SUMMARY")
print("=" * 65)
print(f"""
 Task            | Dataset         | Best Params                         | Metric
 --------------- | --------------- | ----------------------------------- | --------
 SVC (classify)  | Iris            | {grid_svc.best_params_} | Acc={accuracy_score(y_test, y_pred_cls):.4f}
 SVR (regress)   | Boston Housing  | {grid_svr.best_params_} | R2={r2:.4f}

 Plots saved:
   - {plot_path_cls}
   - {plot_path_reg}
""")
