import numpy as np

# AND Gate Truth Table
X = np.array([
    [1, 0, 0],   
    [1, 0, 1],
    [1, 1, 0],
    [1, 1, 1],
])
# Expected outputs for AND gate
y = np.array([0, 0, 0, 1])

def step_function(x):

    return 1 if x >= 0 else 0

def perceptron_train(X, y, learning_rate=0.1, max_epochs=100):
    n_samples, n_features = X.shape
    weights = np.zeros(n_features)  

    print(f"Initial weights: {weights}")
    print(f"Learning rate  : {learning_rate}")
    print(f"Max epochs     : {max_epochs}")
    print("-" * 60)

    for epoch in range(1, max_epochs + 1):
        total_error = 0

        for i in range(n_samples):
            weighted_sum = np.dot(weights, X[i])
            predicted = step_function(weighted_sum)
            error = y[i] - predicted
            total_error += abs(error)
            weights = weights + learning_rate * error * X[i]

        print(f"Epoch {epoch:3d} | Weights: {weights} | Total Error: {total_error}")

        # Converged if no errors
        if total_error == 0:
            print(f"\nConverged at epoch {epoch}!")
            break

    return weights

def perceptron_predict(X, weights):
    predictions = []
    for x in X:
        weighted_sum = np.dot(weights, x)
        predictions.append(step_function(weighted_sum))
    return np.array(predictions)


print("=" * 60)
print("AND GATE - Perceptron Learning Algorithm")
print("=" * 60)
print()


learned_weights = perceptron_train(X, y, learning_rate=0.1, max_epochs=100)

print(f"\nFinal weights: {learned_weights}")
print(f"  w0 (bias weight) = {learned_weights[0]:.2f}")
print(f"  w1               = {learned_weights[1]:.2f}")
print(f"  w2               = {learned_weights[2]:.2f}")

print("\n" + "=" * 60)
print("VERIFICATION")
print("=" * 60)

predictions = perceptron_predict(X, learned_weights)
print(f"\n{'x1':<5} {'x2':<5} {'Expected':<10} {'Predicted':<10} {'Match'}")
print("-" * 40)
for i in range(len(X)):
    match = "Yes" if y[i] == predictions[i] else "No"
    print(f"{X[i][1]:<5} {X[i][2]:<5} {y[i]:<10} {predictions[i]:<10} {match}")

print(f"\nAll predictions correct: {np.array_equal(y, predictions)}")

