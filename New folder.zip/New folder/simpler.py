import numpy as np

np.random.seed(1)

X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
y = np.array([[0], [1], [1], [0]])

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def bce_loss(y, a2):
    eps = 1e-9
    return -np.mean(y * np.log(a2 + eps) + (1 - y) * np.log(1 - a2 + eps))

W1 = np.random.randn(2, 4)
b1 = np.zeros((1, 4))
W2 = np.random.randn(4, 1)
b2 = np.zeros((1, 1))

lr = 0.5
n = len(X)
eps = 1e-9

for epoch in range(10000):

    
    # Forward propagation
    a1 = sigmoid(X @ W1 + b1)
    a2 = sigmoid(a1 @ W2 + b2)
    d2 = (a2 - y) / n
    dW2 = a1.T @ d2
    db2 = np.sum(d2, axis=0, keepdims=True)

    d1 = (d2 @ W2.T) * a1 * (1 - a1)
    dW1 = X.T @ d1
    db1 = np.sum(d1, axis=0, keepdims=True)
    
    # Gradient descent
    W2 -= lr * dW2
    b2 -= lr * db2
    W1 -= lr * dW1
    b1 -= lr * db1



    # a1 = sigmoid(X_train @ W1 + b1)
    # a2 = a1 @ W2 + b2

    # loss = mse_loss(y_train, a2)

    # d2 = 2 * (a2 - y_train) / n
    # dW2 = a1.T @ d2
    # db2 = np.sum(d2, axis=0, keepdims=True)

    # d1 = (d2 @ W2.T) * a1 * (1 - a1)
    # dW1 = X_train.T @ d1
    # db1 = np.sum(d1, axis=0, keepdims=True)

    # W2 -= lr * dW2
    # b2 -= lr * db2
    # W1 -= lr * dW1
    # b1 -= lr * db1
    

# Final predictions
a1 = sigmoid(X @ W1 + b1)
a2 = sigmoid(a1 @ W2 + b2)

print("\nXOR Gate Output")
for xi, out in zip(X, a2):
    print(xi, "->", round(out[0], 3), "=>", int(out[0] > 0.5))
    
