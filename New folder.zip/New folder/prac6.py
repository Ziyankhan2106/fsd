import pandas as pd
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split, cross_val_score, ParameterGrid
from sklearn.tree import DecisionTreeClassifier

data = load_breast_cancer()
X_train, X_test, y_train, y_test = train_test_split(
    data.data, data.target, test_size=0.3, random_state=42)

param_grid = {
    "criterion": ["gini", "entropy"],
    "max_depth": [2, 3, 4, 5, 7, None],
    "min_samples_split": [2, 5, 10, 20],
    "min_samples_leaf": [1, 2, 5, 10],
}

rows = []
for params in ParameterGrid(param_grid):          # every combination
    model = DecisionTreeClassifier(random_state=42, **params)
    cv_acc = cross_val_score(model, X_train, y_train, cv=5).mean()
    model.fit(X_train, y_train)
    params["max_depth"] = str(params["max_depth"])   # show None as text, depth as int-like
    rows.append({**params,
                 "train_acc": model.score(X_train, y_train),
                 "cv_acc": cv_acc,
                 "test_acc": model.score(X_test, y_test)})

table = pd.DataFrame(rows)
table = table.round(3)
table.index = range(1, len(table) + 1)
table.index.name = "config"

pd.set_option("display.width", 200)
print(table.to_string())                 # table of ALL configs

best = table.sort_values("cv_acc", ascending=False, kind="stable").iloc[0]
print("\nBest config (by CV accuracy):")
print(best.to_string())

table.to_csv("/mnt/user-data/outputs/gridsearch_results.csv")
