import numpy as np

np.random.seed(1)

# ---------- Dummy regression data ----------
# True function: y = 2*x1^2 - x2 + 0.5*x1*x2 + noise   (nonlinear, continuous target)
N = 200
X_all = np.random.uniform(-1, 1, size=(N, 2))
y_all = (2 * X_all[:, 0] ** 2
         - X_all[:, 1]
         + 0.5 * X_all[:, 0] * X_all[:, 1]
         + 0.05 * np.random.randn(N)).reshape(-1, 1)

# Train / test split
X_train, X_test = X_all[:160], X_all[160:]
y_train, y_test = y_all[:160], y_all[160:]
n = len(X_train)

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def mse_loss(y, a2):
    return np.mean((y - a2) ** 2)

# ---------- Network: 2 -> 8 (sigmoid) -> 1 (linear) ----------
W1 = np.random.randn(2, 8) * 0.5
b1 = np.zeros((1, 8))
W2 = np.random.randn(8, 1) * 0.5
b2 = np.zeros((1, 1))

lr = 0.5

for epoch in range(5001):

    # ---------- Forward pass ----------
    # z1 = X_train @ W1 + b1
    # a1 = sigmoid(z1)
    # z2 = a1 @ W2 + b2
    # a2 = z2                                   # linear output (no activation)

    # loss = mse_loss(y_train, a2)

    # # ---------- Backward pass (output -> input) ----------

    # # 1) dLoss/da2 : Loss = (1/n) * sum (y - a2)^2
    # dLoss_da2 = 2 * (a2 - y_train) / n        # (160,1)

    # # 2) da2/dz2 : identity activation, derivative is 1
    # da2_dz2 = np.ones_like(a2)                # (160,1)

    # # 3) dLoss/dz2
    # dLoss_dz2 = dLoss_da2 * da2_dz2           # (160,1)

    # # 4) dz2/dW2 = a1,  dz2/db2 = 1
    # dz2_dW2 = a1
    # dLoss_dW2 = dz2_dW2.T @ dLoss_dz2                       # (8,160)@(160,1) = (8,1)
    # dLoss_db2 = np.sum(dLoss_dz2, axis=0, keepdims=True)    # (1,1)

    # # 5) dz2/da1 = W2
    # dz2_da1 = W2
    # dLoss_da1 = dLoss_dz2 @ dz2_da1.T         # (160,1)@(1,8) = (160,8)

    # # 6) da1/dz1 : sigmoid derivative at the hidden layer
    # da1_dz1 = a1 * (1 - a1)                   # (160,8)

    # # 7) dLoss/dz1
    # dLoss_dz1 = dLoss_da1 * da1_dz1           # (160,8)

    # # 8) dz1/dW1 = X,  dz1/db1 = 1
    # dz1_dW1 = X_train
    # dLoss_dW1 = dz1_dW1.T @ dLoss_dz1                       # (2,160)@(160,8) = (2,8)
    # dLoss_db1 = np.sum(dLoss_dz1, axis=0, keepdims=True)    # (1,8)

    # ---------- Gradient descent ----------
    # W2 -= lr * dLoss_dW2
    # b2 -= lr * dLoss_db2
    # W1 -= lr * dLoss_dW1
    # b1 -= lr * dLoss_db1
    a1 = sigmoid(X_train @ W1 + b1)
    a2 = a1 @ W2 + b2

    loss = mse_loss(y_train, a2)

    # ---------- Backpropagation ----------
    d2 = 2 * (a2 - y_train) / n
    dW2 = a1.T @ d2
    db2 = np.sum(d2, axis=0, keepdims=True)

    d1 = (d2 @ W2.T) * a1 * (1 - a1)
    dW1 = X_train.T @ d1
    db1 = np.sum(d1, axis=0, keepdims=True)

    # ---------- Gradient descent ----------
    W2 -= lr * dW2
    b2 -= lr * db2
    W1 -= lr * dW1
    b1 -= lr * db1

    if epoch % 500 == 0:
        print(f"Epoch {epoch}, Train MSE: {loss:.5f}")

# ---------- Evaluation on unseen data ----------
a1_test = sigmoid(X_test @ W1 + b1)
pred = a1_test @ W2 + b2

test_mse = mse_loss(y_test, pred)
ss_res = np.sum((y_test - pred) ** 2)
ss_tot = np.sum((y_test - np.mean(y_test)) ** 2)
r2 = 1 - ss_res / ss_tot

print(f"\nTest MSE: {test_mse:.5f}")
print(f"Test R^2: {r2:.4f}")

print("\nSample predictions (true vs predicted)")
for t, p in zip(y_test[:5], pred[:5]):
    print(f"{t[0]:.3f} vs {p[0]:.3f}")