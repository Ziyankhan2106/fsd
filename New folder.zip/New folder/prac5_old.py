import os
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, Binarizer
from sklearn.naive_bayes import GaussianNB, BernoulliNB, MultinomialNB
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

DATASET_DIR = os.path.join(os.path.dirname(__file__), "..", "datasets")


# 1. Gaussian Naïve Bayes  –  Iris Dataset

print("=" * 60)
print("1. GAUSSIAN NAÏVE BAYES  -  Iris Dataset")
print("=" * 60)

iris = pd.read_csv(os.path.join(DATASET_DIR, "Iris.csv"))
print(f"\nDataset shape: {iris.shape}")
print(iris.head())

# Features: SepalLengthCm, SepalWidthCm, PetalLengthCm, PetalWidthCm
X_iris = iris[["SepalLengthCm", "SepalWidthCm", "PetalLengthCm", "PetalWidthCm"]]
y_iris = LabelEncoder().fit_transform(iris["Species"])

X_train, X_test, y_train, y_test = train_test_split(
    X_iris, y_iris, test_size=0.3, random_state=42
)

gnb = GaussianNB()
gnb.fit(X_train, y_train)
y_pred = gnb.predict(X_test)

print(f"\nAccuracy: {accuracy_score(y_test, y_pred):.4f}")
print("\nConfusion Matrix:")
print(confusion_matrix(y_test, y_pred))
print("\nClassification Report:")
print(classification_report(y_test, y_pred, target_names=["setosa", "versicolor", "virginica"]))



# 2. Bernoulli Naïve Bayes  –  Heart Attack Dataset

print("=" * 60)
print("2. BERNOULLI NAÏVE BAYES  -  Heart Attack Dataset")
print("=" * 60)

heart = pd.read_csv(os.path.join(DATASET_DIR, "heart attack analysis.csv"))
print(f"\nDataset shape: {heart.shape}")
print(heart.head())

# Target: 'output' (0 = less chance, 1 = more chance of heart attack)
X_heart = heart.drop(columns=["output"])
y_heart = heart["output"]

# Binarise continuous features using median threshold (BernoulliNB expects binary data)
binarizer = Binarizer(threshold=0.0)  # BernoulliNB has built-in binarize param
X_train, X_test, y_train, y_test = train_test_split(
    X_heart, y_heart, test_size=0.3, random_state=42
)


# Binarise: value > median → 1, else → 0
medians = X_train.median()
X_train_bin = (X_train > medians).astype(int)
X_test_bin = (X_test > medians).astype(int)

bnb = BernoulliNB()
bnb.fit(X_train_bin, y_train)
y_pred = bnb.predict(X_test_bin)

print(f"\nAccuracy: {accuracy_score(y_test, y_pred):.4f}")
print("\nConfusion Matrix:")
print(confusion_matrix(y_test, y_pred))
print("\nClassification Report:")
print(classification_report(y_test, y_pred, target_names=["Low Risk", "High Risk"]))


# 3. Multinomial Naïve Bayes  –  Student Performance

print("=" * 60)
print("3. MULTINOMIAL NAÏVE BAYES  –  Student Performance Dataset")
print("=" * 60)

student = pd.read_csv(os.path.join(DATASET_DIR, "student-por.csv"), sep=";")
print(f"\nDataset shape: {student.shape}")
print(student.head())

# Select only non-negative integer (count-like) features suitable for Multinomial NB
count_features = [
    "Medu", "Fedu", "traveltime", "studytime", "failures",
    "famrel", "freetime", "goout", "Dalc", "Walc",
    "health", "absences"
]
X_student = student[count_features]

# Target: G3 (final grade 0–20) → binarise into Pass (>=10) / Fail (<10)
y_student = (student["G3"] >= 10).astype(int)

print(f"\nTarget distribution (Pass=1, Fail=0):\n{y_student.value_counts()}")

X_train, X_test, y_train, y_test = train_test_split(
    X_student, y_student, test_size=0.3, random_state=42
)

mnb = MultinomialNB()
mnb.fit(X_train, y_train)
y_pred = mnb.predict(X_test)

print(f"\nAccuracy: {accuracy_score(y_test, y_pred):.4f}")
print("\nConfusion Matrix:")
print(confusion_matrix(y_test, y_pred))
print("\nClassification Report:")
print(classification_report(y_test, y_pred, target_names=["Fail", "Pass"]))


# ──────────────────────────────────────────────
# Summary
# ──────────────────────────────────────────────
print("=" * 60)
print("SUMMARY")
print("=" * 60)
print("""
 Model               | Dataset              | Why this dataset?
 ------------------- | -------------------- | --------------------------------------
 Gaussian NB         | Iris                 | Continuous real-valued features
 Bernoulli NB        | Heart Attack         | Binary / binarisable features
 Multinomial NB      | Student Performance  | Non-negative integer count features
""")
